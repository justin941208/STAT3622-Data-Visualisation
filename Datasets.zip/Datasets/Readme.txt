All.csv: total number of drug abusers over 30 years
Age.csv: number of drug abusers over 30 years sorted by age
Edu.csv: number of drug abusers over 30 years sorted by educational attainment
First.csv: number of drug abusers over 30 years sorted by the age of first abuse
Gender.csv: number of drug abusers over 30 years sorted by gender
multidrug.csv: number of drug abusers over 30 years sorted by whether they take one or more than one drug
Occup.csv: number of drug abusers over 30 years sorted by activity status
Types2.csv: number of drug abusers over 30 years sorted by common types of drug
drug_all.csv: different variables sorted by districts, 
	      column 5 - 24 are total number of drug abusers over 20 years, 
	      column 25 - 44 are density of drug abusers,
              column 45 - 64 are proportion of males,
              column 65 - 84 are proportion of females,
	      column 85 - 104 are log ratio of males to females,
              column 105 - 124 are proportion of abusers under 21,
              column 125 - 144 are proportion of abusers aged 21 or above,
              column 145 - 164 are log ratio of abusers under 21 to those aged 21 or above,
              column 165 - 183 are the most prevalent drug types
HKG_adm1.rds: R spatial polygon dataframe of Hong Kong
hk_drug_map.csv: merged file of drug_all.csv and HKG_adm1.rds by district